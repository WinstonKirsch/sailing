MCN SailOps PWA starter package

Contents:
- index.html: V4.3 Classic interface, local memory and account setup panel
- manifest.webmanifest: installable-app metadata
- service-worker.js: basic app-shell cache for offline opening
- icons/: 192px and 512px app icons

How to use:
1. Upload the CONTENTS of this folder to an HTTPS static host.
2. Open the hosted URL in Chrome on Android or Chrome/Edge on Chromebook.
3. Choose Install app or Add to Home screen from the browser menu.

Important:
- A PWA must be served from HTTPS (or localhost for development); opening index.html as a local file does not enable full PWA installation.
- Local sailing memory stays in the browser on that device. Export backups before clearing browser data.
- Google/email login and cloud sync are NOT active yet. The included account panel is a placeholder until a Supabase project and secure policies are configured.
- Do not place service-role secrets in index.html.
